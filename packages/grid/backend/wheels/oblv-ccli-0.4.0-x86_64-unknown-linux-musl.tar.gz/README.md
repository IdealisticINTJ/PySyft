# Oblv

## About
Oblivious client app for encrypted connection to secure enclaves. 

## Documentation
Please refer to CLI section https://docs.oblivious.ai/cli/introduction in the Developer documentation for information on: 

- Setup
- Key Generation
- Execution
- Available CLI commands
- Usage Examples

## Copyright
@2022 Oblivious Software Ltd. All rights reserved.
